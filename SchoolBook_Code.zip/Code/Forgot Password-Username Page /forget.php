<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>SchoolBook</title>
		<link href="vg_schoolbook.css" type="text/css" rel="stylesheet">
  </head>
<body>

<?php

  $error='';
  if (isset($_POST['submit'])) {

    if (empty($_POST['email']) || empty($_POST['security1'])|| empty($_POST['security2'])) {
      $error = "<p style=\"color:white;\"> One or more field is incorrect </p>";
      echo "$error";
    }
    else {

      $email=$_POST['email'];
      $sec1=$_POST['security1'];
      $sec2=$_POST['security2'];

      $db = mysqli_connect("studentdb-maria.gl.umbc.edu","gy63575","gy63575","gy63575");

	  if (mysqli_connect_errno())
		  exit("Error - could not connect to MySQL");

      $email = stripslashes($email);
      $sec1 = stripslashes($sec1);
      $sec2 = stripslashes($sec2);
    $email = mysqli_real_escape_string($db, $email);
    $sec1 = mysqli_real_escape_string($db, $sec1);
    $sec2 = mysqli_real_escape_string($db, $sec2);


    $query = mysqli_query($db, "SELECT * from USER where email='$email' AND security1='$sec1' AND security2='$sec2'");


    $rows = mysqli_num_rows($query);

    if ($rows == 1) {

      header("location: https://swe.umbc.edu/~plumikh1/is448/SchoolBook/resetpassword.html");
	  die();
    } else {
      $error = "<p style=\"color:white;\"> One or more field is incorrect </p>";
      echo "$error";
    }
    mysqli_close($db);
  }
}
?>
<a href="forgetpassword.html">Go back to Forget Password page</a>
</body>
</html>
