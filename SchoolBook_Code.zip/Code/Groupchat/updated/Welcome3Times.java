// This program prints Welcome to Java! 
public class Welcome3Times {	
  public static void main(String[] args) { 
    System.out.println("Welcome to Java!");
    System.out.println("Welcome to Information Systems!");
    System.out.println("Programming is Fun!");
  }
}
